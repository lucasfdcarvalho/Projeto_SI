
  # Template de site para farmácias

  This is a code bundle for Template de site para farmácias. The original project is available at https://www.figma.com/design/TE3BOkwLoTtmwO9dLmr4R1/Template-de-site-para-farm%C3%A1cias.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  