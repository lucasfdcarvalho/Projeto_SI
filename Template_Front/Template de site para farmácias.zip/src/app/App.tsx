import { Header } from './components/Header';
import { Hero } from './components/Hero';
import { Categories } from './components/Categories';
import { Services } from './components/Services';
import { Footer } from './components/Footer';
import { ChatbotButton } from './components/ChatbotButton';

export default function App() {
  return (
    <div className="min-h-screen bg-white">
      <Header />
      <main>
        <Hero />
        <Categories />
        <Services />
      </main>
      <Footer />
      <ChatbotButton />
    </div>
  );
}