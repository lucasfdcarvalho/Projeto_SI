import { Pill, Heart, Baby, Sparkles, Droplet, Shield } from 'lucide-react';

const categories = [
  { icon: Pill, name: 'Medicamentos', color: 'bg-blue-100 text-blue-600' },
  { icon: Heart, name: 'Vitaminas', color: 'bg-red-100 text-red-600' },
  { icon: Baby, name: 'Infantil', color: 'bg-pink-100 text-pink-600' },
  { icon: Sparkles, name: 'Beleza', color: 'bg-purple-100 text-purple-600' },
  { icon: Droplet, name: 'Dermocosméticos', color: 'bg-cyan-100 text-cyan-600' },
  { icon: Shield, name: 'Higiene', color: 'bg-emerald-100 text-emerald-600' },
];

export function Categories() {
  return (
    <section className="py-16 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-3xl font-bold text-center mb-12">Categorias</h2>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-6">
          {categories.map((category, index) => {
            const Icon = category.icon;
            return (
              <button
                key={index}
                className="flex flex-col items-center gap-3 p-6 rounded-xl hover:shadow-lg transition-shadow border border-gray-100"
              >
                <div className={`w-16 h-16 rounded-full ${category.color} flex items-center justify-center`}>
                  <Icon className="w-8 h-8" />
                </div>
                <span className="text-sm font-medium text-gray-700">{category.name}</span>
              </button>
            );
          })}
        </div>
      </div>
    </section>
  );
}
