import { MessageCircle, X } from 'lucide-react';
import { useState } from 'react';

export function ChatbotButton() {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <>
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="fixed bottom-6 right-6 w-14 h-14 bg-emerald-600 text-white rounded-full shadow-lg hover:bg-emerald-700 transition-all hover:scale-110 flex items-center justify-center z-50"
        aria-label="Abrir chat"
      >
        {isOpen ? (
          <X className="w-6 h-6" />
        ) : (
          <MessageCircle className="w-6 h-6" />
        )}
      </button>

      {isOpen && (
        <div className="fixed bottom-24 right-6 w-80 sm:w-96 bg-white rounded-2xl shadow-2xl z-50 overflow-hidden">
          <div className="bg-emerald-600 text-white p-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center">
                <MessageCircle className="w-6 h-6" />
              </div>
              <div>
                <h3 className="font-bold">Assistente Virtual</h3>
                <p className="text-xs text-emerald-100">Online agora</p>
              </div>
            </div>
          </div>

          <div className="h-96 overflow-y-auto p-4 bg-gray-50">
            <div className="mb-4">
              <div className="bg-white rounded-lg p-3 shadow-sm inline-block max-w-[80%]">
                <p className="text-sm text-gray-700">
                  Olá! 👋 Bem-vindo à FarmaSaúde! Como posso ajudá-lo hoje?
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 gap-2 mt-4">
              <button className="bg-white border border-gray-200 rounded-lg p-3 text-left hover:bg-gray-50 transition-colors">
                <p className="text-sm font-medium text-gray-900">🔍 Buscar medicamento</p>
              </button>
              <button className="bg-white border border-gray-200 rounded-lg p-3 text-left hover:bg-gray-50 transition-colors">
                <p className="text-sm font-medium text-gray-900">📦 Rastrear pedido</p>
              </button>
              <button className="bg-white border border-gray-200 rounded-lg p-3 text-left hover:bg-gray-50 transition-colors">
                <p className="text-sm font-medium text-gray-900">💊 Falar com farmacêutico</p>
              </button>
              <button className="bg-white border border-gray-200 rounded-lg p-3 text-left hover:bg-gray-50 transition-colors">
                <p className="text-sm font-medium text-gray-900">🏷️ Ver ofertas do dia</p>
              </button>
            </div>
          </div>

          <div className="p-4 border-t bg-white">
            <div className="flex gap-2">
              <input
                type="text"
                placeholder="Digite sua mensagem..."
                className="flex-1 px-4 py-2 border border-gray-300 rounded-full focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-transparent"
              />
              <button className="w-10 h-10 bg-emerald-600 text-white rounded-full hover:bg-emerald-700 transition-colors flex items-center justify-center">
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" />
                </svg>
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
