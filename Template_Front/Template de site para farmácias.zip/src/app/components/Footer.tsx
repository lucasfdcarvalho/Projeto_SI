import { Facebook, Instagram, Twitter, Mail, Phone, MapPin } from 'lucide-react';

export function Footer() {
  return (
    <footer className="bg-gray-900 text-white pt-12 pb-6">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid md:grid-cols-4 gap-8 mb-8">
          <div>
            <div className="flex items-center gap-2 mb-4">
              <div className="w-10 h-10 bg-emerald-600 rounded-full flex items-center justify-center">
                <span className="text-white text-xl">+</span>
              </div>
              <span className="text-xl font-bold">FarmaSaúde</span>
            </div>
            <p className="text-gray-400 mb-4">
              Cuidando da sua saúde com qualidade e dedicação.
            </p>
            <div className="flex gap-3">
              <a href="#" className="w-10 h-10 bg-gray-800 rounded-full flex items-center justify-center hover:bg-emerald-600 transition-colors">
                <Facebook className="w-5 h-5" />
              </a>
              <a href="#" className="w-10 h-10 bg-gray-800 rounded-full flex items-center justify-center hover:bg-emerald-600 transition-colors">
                <Instagram className="w-5 h-5" />
              </a>
              <a href="#" className="w-10 h-10 bg-gray-800 rounded-full flex items-center justify-center hover:bg-emerald-600 transition-colors">
                <Twitter className="w-5 h-5" />
              </a>
            </div>
          </div>

          <div>
            <h3 className="font-bold mb-4">Links Rápidos</h3>
            <ul className="space-y-2">
              <li><a href="#" className="text-gray-400 hover:text-emerald-400 transition-colors">Medicamentos</a></li>
              <li><a href="#" className="text-gray-400 hover:text-emerald-400 transition-colors">Ofertas</a></li>
              <li><a href="#" className="text-gray-400 hover:text-emerald-400 transition-colors">Serviços</a></li>
              <li><a href="#" className="text-gray-400 hover:text-emerald-400 transition-colors">Blog</a></li>
            </ul>
          </div>

          <div>
            <h3 className="font-bold mb-4">Atendimento</h3>
            <ul className="space-y-2">
              <li><a href="#" className="text-gray-400 hover:text-emerald-400 transition-colors">Central de Ajuda</a></li>
              <li><a href="#" className="text-gray-400 hover:text-emerald-400 transition-colors">Política de Privacidade</a></li>
              <li><a href="#" className="text-gray-400 hover:text-emerald-400 transition-colors">Termos de Uso</a></li>
              <li><a href="#" className="text-gray-400 hover:text-emerald-400 transition-colors">Trocas e Devoluções</a></li>
            </ul>
          </div>

          <div>
            <h3 className="font-bold mb-4">Contato</h3>
            <ul className="space-y-3">
              <li className="flex items-center gap-2 text-gray-400">
                <Phone className="w-5 h-5" />
                <span>(11) 3000-0000</span>
              </li>
              <li className="flex items-center gap-2 text-gray-400">
                <Mail className="w-5 h-5" />
                <span>contato@farmasaude.com</span>
              </li>
              <li className="flex items-start gap-2 text-gray-400">
                <MapPin className="w-5 h-5 mt-1" />
                <span>Av. Paulista, 1000<br />São Paulo - SP</span>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-gray-800 pt-6 text-center text-gray-400">
          <p>&copy; 2026 FarmaSaúde. Todos os direitos reservados.</p>
        </div>
      </div>
    </footer>
  );
}
