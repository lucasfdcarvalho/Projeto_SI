import { ShoppingCart, User, Search, Menu } from 'lucide-react';
import { useState } from 'react';

export function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  return (
    <header className="bg-white shadow-sm sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center gap-8">
            <div className="flex items-center gap-2">
              <div className="w-10 h-10 bg-emerald-600 rounded-full flex items-center justify-center">
                <span className="text-white text-xl">+</span>
              </div>
              <span className="text-xl font-bold text-emerald-600">FarmaSaúde</span>
            </div>

            <nav className="hidden md:flex gap-6">
              <a href="#medicamentos" className="text-gray-700 hover:text-emerald-600 transition-colors">
                Medicamentos
              </a>
              <a href="#ofertas" className="text-gray-700 hover:text-emerald-600 transition-colors">
                Ofertas
              </a>
              <a href="#servicos" className="text-gray-700 hover:text-emerald-600 transition-colors">
                Serviços
              </a>
              <a href="#sobre" className="text-gray-700 hover:text-emerald-600 transition-colors">
                Sobre
              </a>
              <a href="#contato" className="text-gray-700 hover:text-emerald-600 transition-colors">
                Contato
              </a>
            </nav>
          </div>

          <div className="hidden md:flex items-center gap-4">
            <div className="relative">
              <input
                type="text"
                placeholder="Buscar produtos..."
                className="pl-10 pr-4 py-2 border border-gray-300 rounded-full focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-transparent"
              />
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
            </div>

            <button className="p-2 hover:bg-gray-100 rounded-full transition-colors">
              <User className="w-6 h-6 text-gray-700" />
            </button>

            <button className="p-2 hover:bg-gray-100 rounded-full transition-colors relative">
              <ShoppingCart className="w-6 h-6 text-gray-700" />
              <span className="absolute -top-1 -right-1 bg-emerald-600 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                0
              </span>
            </button>
          </div>

          <button
            className="md:hidden p-2"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            <Menu className="w-6 h-6 text-gray-700" />
          </button>
        </div>

        {isMenuOpen && (
          <div className="md:hidden py-4 border-t">
            <nav className="flex flex-col gap-4">
              <a href="#medicamentos" className="text-gray-700 hover:text-emerald-600">
                Medicamentos
              </a>
              <a href="#ofertas" className="text-gray-700 hover:text-emerald-600">
                Ofertas
              </a>
              <a href="#servicos" className="text-gray-700 hover:text-emerald-600">
                Serviços
              </a>
              <a href="#sobre" className="text-gray-700 hover:text-emerald-600">
                Sobre
              </a>
              <a href="#contato" className="text-gray-700 hover:text-emerald-600">
                Contato
              </a>
            </nav>
          </div>
        )}
      </div>
    </header>
  );
}
